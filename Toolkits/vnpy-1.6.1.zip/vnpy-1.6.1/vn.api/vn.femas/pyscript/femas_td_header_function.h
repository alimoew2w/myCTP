int reqnRequestLog(dict req, int nRequestID);

int reqUserLogin(dict req, int nRequestID);

int reqUserLogout(dict req, int nRequestID);

int reqUserPasswordUpdate(dict req, int nRequestID);

int reqOrderInsert(dict req, int nRequestID);

int reqOrderAction(dict req, int nRequestID);

int reqQryOrder(dict req, int nRequestID);

int reqQryTrade(dict req, int nRequestID);

int reqQryUserInvestor(dict req, int nRequestID);

int reqQryTradingCode(dict req, int nRequestID);

int reqQryInvestorAccount(dict req, int nRequestID);

int reqQryInstrument(dict req, int nRequestID);

int reqQryExchange(dict req, int nRequestID);

int reqQryInvestorPosition(dict req, int nRequestID);

int reqSubscribeTopic(dict req, int nRequestID);

int reqQryComplianceParam(dict req, int nRequestID);

int reqQryTopic(dict req, int nRequestID);

int reqQryInvestorFee(dict req, int nRequestID);

int reqQryInvestorMargin(dict req, int nRequestID);

