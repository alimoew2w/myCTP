# vn.api - API接口的Python封装

### 内盘
* vn.ctp：CTP接口
* vn.lts：华宝LTS接口
* vn.femas：飞马接口
* vn.xspeed：飞创接口
* vn.qdp：量投QDP接口
* vn.sgit：飞鼠接口
* vn.ksotp：金仕达期权接口
* vn.ksgold：金仕达黄金接口

### 外盘
* vn.ib：Interactive Brokers接口
* vn.oanda：OANDA接口
* vn.shzd：直达期货接口

### 比特币
* vn.okcoin：币行接口
* vn.huobi：火币接口
* vn.lhang：链行接口

### 数据下载
* vn.datayes：通联数据接口