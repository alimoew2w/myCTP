void processFrontConnected(Task task);

void processFrontDisconnected(Task task);

void processRspUserLogin(Task task);

void processRspUserLogout(Task task);

void processNtyMktStatus(Task task);

void processRspQryInstrument(Task task);

void processRtnDepthMarketData(Task task);

void processRspOrderInsert(Task task);

void processErrRtnOrderInsert(Task task);

void processRtnOrder(Task task);

void processForceLogout(Task task);

void processRspOrderAction(Task task);

void processErrRtnOrderAction(Task task);

void processRtnTrade(Task task);

void processRspQryTradingAccount(Task task);

void processRspQryOrder(Task task);

void processRspQryTrade(Task task);

void processRspQryInvestorPosition(Task task);

void processRspQryClientStorage(Task task);

void processRspSubMarketData(Task task);

