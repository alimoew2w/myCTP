# vn.shzd

### 简介
直达期货接口的Python封装，主要用于外盘期货交易，可以提供比IB更低的行情和交易延时，以及更好的交易稳定性，适合专业机构使用。

### API版本

日期：2015-10-16

名称：ShZd-Dll_20151016

链接：[http://www.directaccess.com.hk/software/download.html](http://www.directaccess.com.hk/software/download.html)
