int reqUserLogin(dict req, int nRequestID);

int reqUserLogout(dict req, int nRequestID);

int reqSubscribeTopic(dict req, int nRequestID);

int reqQryTopic(dict req, int nRequestID);

int reqSubMarketData(dict req, int nRequestID);

int reqUnSubMarketData(dict req, int nRequestID);

int reqQryDepthMarketData(dict req, int nRequestID);

