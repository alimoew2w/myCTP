# vn.xspeed

### 简介
大连飞创XSpeed期货柜台接口API的Python封装

### 说明
由于飞创API的原生头文件中的代码排版格式较差（空格不规范、代码缩进不规范），在pyscript脚本生成封装代码的过程中有大量函数出错，需要手动修改。


### API版本

日期：2016-02-19

名称：XSpeedAPI_V1.0.9.14_sp3

链接：[http://www.dfitc.com.cn/portal/cate?cid=1364967839100#1](http://www.dfitc.com.cn/portal/cate?cid=1364967839100#1)
