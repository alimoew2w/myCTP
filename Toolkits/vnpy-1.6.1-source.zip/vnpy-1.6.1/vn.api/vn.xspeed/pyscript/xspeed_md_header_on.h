

virtual void onRspUserLogin(dict data, dict error) {};

virtual void onRspUserLogout(dict data, dict error) {};

virtual void onRspError(dict error) {};

virtual void onRspSubMarketData(dict data, dict error) {};

virtual void onRspUnSubMarketData(dict data, dict error) {};

virtual void onRspSubForQuoteRsp(dict data, dict error) {};

virtual void onRspUnSubForQuoteRsp(dict data, dict error) {};



virtual void onRtnForQuoteRsp(dict data) {};

virtual void onRspTradingDay(dict data, dict error) {};

