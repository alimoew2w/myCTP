int reqUserLogin(dict req, int nRequestID);

int reqUserLogout(dict req, int nRequestID);

int reqFetchAuthRandCode(dict req, int nRequestID);

int reqOrderInsert(dict req, int nRequestID);

int reqOrderAction(dict req, int nRequestID);

int reqUserPasswordUpdate(dict req, int nRequestID);

int reqTradingAccountPasswordUpdate(dict req, int nRequestID);

int reqFundOutByLiber(dict req, int nRequestID);

int reqFundInterTransfer(dict req, int nRequestID);

