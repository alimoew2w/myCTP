# coding: utf-8

def register(username, password, email):
    pass

def login(username, password):
    """

    :param username:
    :param password:
    :return:
    """
    pass

def update_token(username):
    pass

