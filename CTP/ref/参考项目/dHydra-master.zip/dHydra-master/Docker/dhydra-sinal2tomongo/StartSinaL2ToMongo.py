# coding: utf-8
from dHydra.main import start_worker

start_worker(
    worker_name="SinaL2ToMongo",
    nickname="SinaL2ToMongo",
)